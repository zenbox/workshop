Gesamtdauer: 3 Stunden  
Teilnehmende: 6 Personen im Übungssetting  
Ziel: Die Gruppe erkennt operative Aufgaben, Bedarfe, Risiken und Unterstützungsmöglichkeiten und entwickelt konkrete Maßnahmen für die nächsten zwei Wochen.

## Raumvorbereitung vor Workshopbeginn

Vorbereitete Wandflächen:

-       1. Was bedeutet operationale Synergie?
-       2. Aufgabenliste / Beschreibung
-       3. Bedarf
-       4. Leitplanken / Rahmenbedingungen / Gefahren / Hindernisse
-       5. Arbeits-Päckchen
-       6. Verteilungsbörse
-       7. Maßnahmenwerkstatt
-       8. Abschluss / nächste Schritte

Material:

- Moderationskarten
- Post-its in mehreren Farben
- dicke Stifte
- Klebepunkte
- Magnete / Klebeband
- Timer
- vorbereitete Arbeits-Päckchen-Vorlagen
- vorbereitete Maßnahmenkarten
- Gruppentische
- Außengelände oder Flurroute für Spaziergang

Wichtig:

- Pause direkt vor dem Spaziergang einplanen.
- Spaziergang mit klarem Arbeitsauftrag starten.
- Immer wieder auf Überlastungsschutz achten.
- Übereifrige Personen würdigen, aber begrenzen.
- Stille Personen aktiv aktivieren.