**Moderationsprompt an den Multipersonen-Chatbot:**

Wir haben jetzt viele Aufgaben gesammelt.

Bitte wählt pro Person 1 Aufgabe aus, die andere möglicherweise unterschätzen.

Erklärt kurz:

1. Was steckt wirklich dahinter?
2. Warum ist die Aufgabe bei Ausfall kritisch?
3. Welche Information braucht jemand, um unterstützen zu können?

Bitte antwortet kurz und realistisch.