**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten Abschnitt 5: Arbeits-Päckchen.

Ziel ist, große oder unklare Aufgaben in kleine, übernehmbare Pakete zu zerlegen.

Format:

Eine Person ist Host für eine Aufgabe.  
Zwei Personen sind Guests und stellen Fragen.  
Danach entsteht ein Arbeits-Päckchen.

Bitte bildet zwei Gruppen:

Gruppe A:

- 1 Host
- 2 Guests

Gruppe B:

- 1 Host
- 2 Guests

Aufgabe:

1. Der Host wählt eine kritische Aufgabe aus.
2. Die Guests stellen je 2–3 Fragen:
    - Was genau ist zu tun?
    - Was ist der nächste Schritt?
    - Welche Information braucht man?
    - Wie lange dauert es?
    - Was kann schiefgehen?
    - Wobei könnte jemand unterstützen?
3. Danach formuliert jede Gruppe ein Arbeits-Päckchen.

Gewünschtes Ergebnisformat:

Gruppe A:  
Host:  
Guests:

Ausgewählte Aufgabe:

- …

Fragen und Antworten:

- …

Arbeits-Päckchen:

- Titel:
- Kurzbeschreibung:
- Aufwand:
- Benötigtes Wissen:
- Risiko:
- Unterstützung möglich durch:
- Erste Einweisung nötig: ja/nein

Gruppe B:  
…

Bitte zeigt dabei realistische Unsicherheiten und Rückfragen.