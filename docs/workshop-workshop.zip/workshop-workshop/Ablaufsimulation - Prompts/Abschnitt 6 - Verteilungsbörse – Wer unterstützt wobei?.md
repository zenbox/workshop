**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten Abschnitt 6: Verteilungsbörse.

Die Arbeits-Päckchen hängen jetzt sichtbar im Raum.

Aufgabe:

Jede Person markiert zu mehreren Arbeits-Päckchen:

- „Kann ich übernehmen.“
- „Kann ich unterstützen.“
- „Kann ich mit kurzer Einweisung.“
- „Kann ich nicht.“
- „Brauche ich selbst Unterstützung.“

Bitte antwortet als Personas.

Gewünschtes Antwortformat:

Markus:  
Ich markiere:

- Arbeits-Päckchen …: kann ich übernehmen
- Arbeits-Päckchen …: kann ich unterstützen
- Arbeits-Päckchen …: brauche kurze Einweisung

Begründung:

- …

Bitte achtet auf Gruppendynamik:

- Die Übereifrigen dürfen zu viel nehmen.
- Die Skepsis darf fragen, ob das realistisch ist.
- Die empathische Person darf Überlastung ansprechen.
- Die zurückhaltende Person braucht eventuell Aktivierung.