**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten mit Abschnitt 1: Card Sorting.

Ziel ist, ein gemeinsames Verständnis von „Synergie“ und „operational“ zu bekommen.

Bitte reagiert als Teilnehmende mit kurzen Karteninhalten.

Aufgabe:

1. Jede Person schreibt 2 Karten zum Begriff „Synergie“.
2. Jede Person schreibt 2 Karten zum Begriff „operational“.
3. Danach nennt jede Person kurz, welche Karte ihr besonders wichtig ist und warum.

Bitte antwortet im Persona-Format.

Gewünschtes Antwortformat:

Markus:  
Synergie-Karten:

- …
- …  
    Operational-Karten:
- …
- …  
    Wichtigste Karte:
- …, weil …

Sarah:  
…

Bitte bleibt realistisch: Manche Karten dürfen doppelt, unscharf, kritisch oder alltagssprachlich sein.