**Moderationsprompt an den Multipersonen-Chatbot:**

Wir wählen jetzt 3 bis 5 Maßnahmen aus.

Bitte diskutiert kurz aus euren Rollen:

1. Welche Maßnahme ist sofort hilfreich?
2. Welche Maßnahme ist unrealistisch?
3. Welche Maßnahme schützt vor Überlastung?
4. Welche Maßnahme darf nicht versanden?
5. Welche Maßnahme braucht eine verantwortliche Person?

Danach einigt euch auf 3 bis 5 Maßnahmen.

Bitte antwortet mit kurzer Diskussion und anschließend mit einer finalen Maßnahmenliste.

Finales Format:

Ausgewählte Maßnahmen:

1. …
2. …
3. …
4. …
5. …

Nicht ausgewählt:

- …, weil …