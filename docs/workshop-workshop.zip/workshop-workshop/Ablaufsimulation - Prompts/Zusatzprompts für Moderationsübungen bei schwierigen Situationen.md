## Übereifrige Person bremsen

Markus oder Lea übernimmt gerade zu viel oder springt zu schnell in Lösungen.

Bitte reagiert realistisch aus der Gruppe:

- Eine Person findet das hilfreich.
- Eine Person findet es zu schnell.
- Eine Person weist auf Überlastung hin.
- Eine Person bleibt still oder unsicher.

Der Facilitator soll üben, die Energie wertzuschätzen und gleichzeitig zu strukturieren.

## Stille Person aktivieren

Jens war längere Zeit still.

Bitte reagiert auf eine direkte, freundliche Aktivierung durch den Facilitator:

„Jens, du bist nah an den täglichen Abläufen. Welche Aufgabe wird aus deiner Sicht oft unterschätzt?“

Jens soll erst zögerlich antworten, dann aber einen wichtigen praktischen Hinweis geben.  
Andere Personas dürfen kurz darauf reagieren.

## Skepsis auffangen

Tom stellt den Sinn der Methode infrage.

Bitte reagiert auf folgende Moderationssituation:

Tom sagt sinngemäß:  
„Ich weiß nicht, ob uns diese Karten wirklich helfen. Am Ende hängt es doch wieder an denselben Leuten.“

Die anderen Personas sollen unterschiedlich reagieren:

- Zustimmung
- leichte Abwehr
- Vermittlung
- praktische Umdeutung

Der Facilitator soll üben, Skepsis als wichtigen Hinweis aufzunehmen.

## Überlastung sichtbar machen

Bitte simuliert eine Situation, in der mehrere Personen merken, dass die Verteilung unfair werden könnte.

Markus bietet an, sehr viel zu übernehmen.  
Lea bietet ebenfalls mehrere Dinge an.  
Nina weist auf Überlastung hin.  
Sarah fragt nach Kriterien.  
Jens bleibt zunächst still.  
Tom fragt, wer das nachhält.

Bitte antwortet realistisch und knapp.

## Unklare Aufgabe klären

Bitte simuliert eine Aufgabe, die erst viel zu groß formuliert ist, zum Beispiel:

„Kundenkommunikation verbessern“

Die Personas sollen helfen, daraus ein konkretes Arbeits-Päckchen zu machen.

Ziel:

Aus der großen Aufgabe soll ein kleines Paket entstehen, zum Beispiel:

- Standardantworten für 3 häufige Kundenfragen sammeln
- Übergabe bei offenen Kundenvorgängen klären
- Statusliste für Rückmeldungen pflegen

Bitte antwortet als Workshopgruppe.

## Maßnahmen werden zu groß

Bitte simuliert eine Situation in Abschnitt 7, in der eine Maßnahme zu groß wird.

Beispiel:

„Wir bauen ein komplett neues Wissensmanagement-System.“

Die Personas sollen unterschiedlich reagieren:

- Begeisterung
- Skepsis
- Wunsch nach kleinerem Test
- Frage nach Aufwand
- Vorschlag für 2-Wochen-Experiment

Ziel ist, dass der Facilitator übt, große Ideen in kleine Experimente zu übersetzen.