**Moderationsprompt an den Multipersonen-Chatbot:**

Bitte prüft jetzt die entstandenen Arbeits-Päckchen.

Jede Persona reagiert kurz auf ein Arbeits-Päckchen:

1. Ist es klein genug?
2. Ist es verständlich genug?
3. Könnte jemand anderes es übernehmen?
4. Was fehlt noch?

Bitte auch kritisch antworten, wenn etwas noch zu groß oder zu unklar ist.