**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten Abschnitt 7: Maßnahmenwerkstatt.

Die bisherigen Ergebnisse sind:

- Begriffscluster
- Aufgabenliste
- Bedarfskarte
- Leitplanken
- Arbeits-Päckchen
- Verteilungsbörse

Jetzt entwickeln wir konkrete Maßnahmen für die nächsten zwei Wochen.

Bitte nutzt Zielverben als Impulse.

Mögliche Zielverben:

- einführen
- benennen
- erklären
- umsetzen
- verschriftlichen
- verteilen
- handeln
- investieren
- vorantreiben
- bewerten

Aufgabe:

Jede Person schlägt 1 konkrete Maßnahme vor.

Jede Maßnahme muss dieses Format haben:

- Maßnahme:
- Zielverb:
- Welches Problem löst sie?
- Wer ist beteiligt?
- Start:
- Aufwand:
- Woran merken wir Wirkung?
- Prüfung nach 2 Wochen:
- Risiko:

Bitte bleibt realistisch: Die Maßnahmen sollen klein, testbar und nicht überfordernd sein.