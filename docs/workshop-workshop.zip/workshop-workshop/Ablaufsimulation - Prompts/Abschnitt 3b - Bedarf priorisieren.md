**Moderationsprompt an den Multipersonen-Chatbot:**

Wir priorisieren jetzt den Bedarf mit einer einfachen Ampel.

Bitte bewertet aus eurer Sicht 3 Aufgaben oder Bedarfe:

- Grün: läuft stabil
- Gelb: wackelt
- Rot: kritisch bei Ausfall

Nennt jeweils kurz eine Begründung.

Bitte antwortet als Personas und reagiert auch kurz, wenn ihr eine Einschätzung anders seht.