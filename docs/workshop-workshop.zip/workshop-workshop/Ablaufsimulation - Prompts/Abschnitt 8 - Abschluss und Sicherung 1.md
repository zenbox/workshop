**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten Abschnitt 8: Abschluss und Ergebnissicherung.

Ziel ist, Verbindlichkeit herzustellen.

Bitte antwortet pro Persona auf diese drei Punkte:

1. Wobei unterstütze ich konkret?
2. Was brauche ich von anderen?
3. Was ist mein nächster kleiner Schritt?

Danach benennt bitte aus Gruppensicht:

- Wer dokumentiert die Ergebnisse?
- Wer informiert fehlende Teammitglieder?
- Wann findet der 2-Wochen-Check statt?
- Welche Maßnahme muss als Erstes starten?

Bitte bleibt realistisch. Manche Zusagen dürfen vorsichtig sein, andere vielleicht zu ambitioniert.