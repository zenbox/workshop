**Moderationsprompt an den Multipersonen-Chatbot:**

Wir brauchen jetzt einen gemeinsamen Arbeitssatz.

Bitte formuliert aus eurer Sicht jeweils einen kurzen Satz:

„Operationale Synergien bedeuten für uns …“

Danach reagiert kurz darauf, welcher Satz am brauchbarsten klingt.

Bitte bleibt alltagsnah und nicht zu theoretisch.