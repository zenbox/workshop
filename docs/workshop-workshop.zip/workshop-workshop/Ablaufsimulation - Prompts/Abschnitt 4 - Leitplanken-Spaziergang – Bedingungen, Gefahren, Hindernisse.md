**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten Abschnitt 4: Leitplanken-Spaziergang.

Ihr geht in Paaren oder Dreiergruppen nach draußen.

Arbeitsauftrag für den Spaziergang:

Bitte besprecht aus eurer Rolle:

1. Was darf durch gegenseitige Unterstützung auf keinen Fall passieren?
2. Wo droht neue Überlastung?
3. Welche Grenzen müssen wir beachten?
4. Welche Rahmenbedingungen brauchen wir?
5. Was ist ein echtes Hindernis?
6. Was ist nur Gewohnheit?

Bitte bildet selbst zwei Spaziergangsgruppen:

- eine Gruppe mit 3 Personen
- eine Gruppe mit 3 Personen

Jede Gruppe bringt danach 4 Karten zurück:

- 1 Karte: Gefahr
- 1 Karte: Hindernis
- 1 Karte: notwendige Rahmenbedingung
- 1 Karte: guter Grundsatz

Bitte antwortet im Persona-Format, aber geordnet nach Spaziergangsgruppe.