**Moderationsprompt an den Multipersonen-Chatbot:**

Wir sind zurück im Raum.

Bitte stellt eure Leitplanken-Karten kurz vor.

Danach diskutiert knapp:

1. Welche Leitplanke ist unverzichtbar?
2. Wo könnte es Konflikte geben?
3. Welche Leitplanke schützt vor Überlastung?
4. Welche Leitplanke macht Unterstützung überhaupt möglich?

Bitte bleibt realistisch: Es darf Uneinigkeit geben.