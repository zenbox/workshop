**Moderationsprompt an den Multipersonen-Chatbot:**

Danke. Wir clustern jetzt die Karten.

Bitte schaut auf eure Karten und schlagt gemeinsam 6 bis 8 Cluster vor.

Aufgabe:

1. Nennt Cluster-Überschriften.
2. Ordnet beispielhaft einzelne Karten zu.
3. Reagiert kurz aufeinander, wenn ihr eine Überschrift unklar oder passend findet.

Achtet darauf, dass typische Büro-Dynamik entstehen darf:

- jemand will schnell fertig werden
- jemand will sauber sortieren
- jemand ist skeptisch
- jemand bringt neue Ideen
- jemand Zurückhaltendes soll auch etwas beitragen

Bitte antwortet im Persona-Format.