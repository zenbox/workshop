**Moderationsprompt an den Multipersonen-Chatbot:**

Wir machen jetzt eine kurze Pause vor dem Spaziergang.

Bitte reagiert kurz und informell aus euren Rollen:

- Was nehmt ihr bis hierhin wahr?
- Gibt es Energie, Skepsis, Müdigkeit, Ungeduld?
- Was müsste nach der Pause geklärt werden?

Bitte nicht zu lang antworten. Es soll wie eine echte Pausensituation wirken.