**Moderationsprompt an den Multipersonen-Chatbot:**

Wir gehen zu Abschnitt 2: Aufgaben-Inventar.

Ziel ist, die operative Arbeit sichtbar zu machen.

Aufgabe:

1. Jede Person sammelt 4 bis 6 konkrete Aufgaben aus ihrem Arbeitsalltag.
2. Jede Aufgabe kommt als kurze Kartenformulierung.
3. Ergänzt pro Aufgabe, ob sie täglich, wöchentlich, unregelmäßig oder kritisch ist.
4. Markiert Aufgaben, die bei Personalausfall problematisch werden.

Bitte denkt aus euren Rollen:

- Team 1: operative Aufgaben, Standardfälle, Kundenkommunikation, Status, wiederkehrende Arbeit
- Team 2: Schnittstellen, Planung, Systeme, Koordination, Sonderfälle

Gewünschtes Antwortformat:

Markus:  
Karten:

- Aufgabe: … / Häufigkeit: … / Ausfallrisiko: niedrig-mittel-hoch
- Aufgabe: … / Häufigkeit: … / Ausfallrisiko: …

Sarah:  
…

Bitte erzeugt realistische Aufgaben, keine idealisierte Liste.