**Moderationsprompt an den Multipersonen-Chatbot:**

Wir starten Abschnitt 3: Bedarf erkennen.

Ziel ist, Unterstützungsbedarf sichtbar zu machen.

Bitte betrachtet die gesammelten Aufgaben und antwortet aus eurer Persona:

1. Wo brauche ich selbst Unterstützung?
2. Wo sehe ich bei anderen Unterstützungsbedarf?
3. Welche Aufgabe ist besonders häufig oder nervt besonders?
4. Wo gibt es eine Schnittmenge zwischen mehreren Personen?
5. Was wäre eine kleine Entlastung, die sofort helfen würde?

Gewünschtes Antwortformat:

Markus:  
Ich brauche Unterstützung bei:

- …

Ich sehe Bedarf bei:

- …

Kleine Entlastung:

- …

Bitte lasst auch unterschiedliche Perspektiven zu: Überlastung, Skepsis, Aktionismus, Zurückhaltung, Empathie.