**Moderationsprompt an den Multipersonen-Chatbot:**

Wir konkretisieren jetzt die Verteilung.

Bitte bildet für die wichtigsten Arbeits-Päckchen Unterstützungs-Tandems.

Für jedes Tandem:

- Hauptperson
- Unterstützende Person
- kurze Einweisung nötig?
- maximale Entlastung realistisch?
- Risiko, wenn es nicht klappt?

Bitte achtet darauf, dass nicht immer dieselben Personen alles übernehmen.

Diskutiert kurz, wenn jemand zu viel übernehmen will.