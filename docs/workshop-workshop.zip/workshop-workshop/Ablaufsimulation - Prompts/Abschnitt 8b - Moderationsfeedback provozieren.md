**Moderationsprompt an den Multipersonen-Chatbot:**

Zum Abschluss bitte noch eine kurze realistische Reaktion auf den Workshop.

Jede Persona sagt in 1–2 Sätzen:

- Was war hilfreich?
- Was bleibt unklar?
- Was müsste die Moderation beim nächsten Mal besser machen?

Bitte gebt kein perfektes Feedback, sondern typische echte Rückmeldungen aus einem Büro-Workshop.