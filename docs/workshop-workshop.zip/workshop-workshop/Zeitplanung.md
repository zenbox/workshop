|             |         |                            |                                                   |
| ----------- | ------- | -------------------------- | ------------------------------------------------- |
| 9:00–9:20   | 20 Min. | 1. Card Sorting            | Begriffe klären, gemeinsames Verständnis schaffen |
| 09:25–09:45 | 20 Min. | 2. Aufgaben-Inventar       | operative Aufgaben sichtbar machen                |
| 09:45–10:05 | 20 Min. | 3. Bedarf erkennen         | Unterstützungsbedarf und Schnittmengen erkennen   |
| 10:05–10:15 | 10 Min. | Pause                      | Energie holen, Raumwechsel vorbereiten            |
| 10:15–10:40 | 25 Min. | 4. Leitplanken-Spaziergang | Bedingungen, Hindernisse und Risiken sammeln      |
| 10:40–11:05 | 25 Min. | 5. Arbeits-Päckchen        | Aufgaben klein und übernehmbar machen             |
| 11:05–11:30 | 25 Min. | 6. Verteilungsbörse        | Unterstützung zuordnen                            |
| 11:30–11:50 | 20 Min. | 7. Maßnahmenwerkstatt      | konkrete Maßnahmen ableiten                       |
| 11:50–12:00 | 10 Min. | 8. Abschluss und Sicherung | Verantwortlichkeiten und Follow-up klären         |

